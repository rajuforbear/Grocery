import { View, Text } from 'react-native'
import React from 'react'

const Delivery = () => {
  return (
    <View>
      <Text>Delivery</Text>
    </View>
  )
}

export default Delivery