import { View, Text } from 'react-native'
import React from 'react'

const Chat = () => {
  return (
    <View>
      <Text>Chat</Text>
    </View>
  )
}

export default Chat